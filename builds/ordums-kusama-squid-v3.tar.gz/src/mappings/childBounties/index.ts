import * as extrinsic from './extrinsics'
import * as events from './events'

export default {
    events,
    extrinsic,
}