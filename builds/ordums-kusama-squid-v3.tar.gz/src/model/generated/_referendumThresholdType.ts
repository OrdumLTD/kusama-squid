export enum ReferendumThresholdType {
    SuperMajorityApprove = "SuperMajorityApprove",
    SuperMajorityAgainst = "SuperMajorityAgainst",
    SimpleMajority = "SimpleMajority",
}
